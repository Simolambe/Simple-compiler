package test;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;

import scanner.LexicalException;
import scanner.Scanner;
import token.Token;
import token.TokenType;

class TestScanner {

    Scanner scan;

    
    
    @Test
    void testGenerale() throws LexicalException {
        scan = new Scanner("test/data/testScanner/testGenerale.txt");
        String[] tokenTest = { "<TYINT,r:1>", "<ID,r:1,temp>", "<SEMI,r:1>",
                "<ID,r:2,temp>", "<ASSIGN,r:2>", "<FLOAT,r:2,5.>", "<SEMI,r:2>",
                "<TYFLOAT,r:4>", "<ID,r:4,b>", "<ASSIGN,r:4>", "<INT,r:4,0>", "<SEMI,r:4>",
                "<ID,r:5,b>", "<ASSIGN,r:5>", "<ID,r:5,temp>", "<PLUS,r:5>", "<FLOAT,r:5,3.2>", "<SEMI,r:5>",
                "<PRINT,r:6>", "<ID,r:6,b>", "<SEMI,r:6>",
                "<EOF,r:7>" };

        int i = 0;
        while (i < tokenTest.length) {
            Token token = scan.nextToken();
            assertEquals(tokenTest[i], token.toString());
            i++;
        }
    }
    
    

    @Test
    void testKeywords() throws LexicalException {
        scan = new Scanner("test/data/testScanner/testKeywords.txt");
        String[] tokenTest = { "<PRINT,r:2>", "<TYFLOAT,r:2>", "<TYINT,r:5>", "<EOF,r:5>" };

        int i = 0;
        while (i < tokenTest.length) {
            Token token = scan.nextToken();
            assertEquals(tokenTest[i], token.toString());
            i++;
        }
    }
    

    @Test
    void testINT() throws LexicalException {
        scan = new Scanner("test/data/testScanner/testINT.txt");
        String[] tokenTest = { "<INT,r:2,698>", "<EOF,r:2>" };

        int i = 0;
        while (i < tokenTest.length) {
            Token token = scan.nextToken();
            assertEquals(tokenTest[i], token.toString());
            i++;
        }
    }

    @Test
    void testOperators() throws LexicalException {
        scan = new Scanner("test/data/testScanner/testOperators.txt");
        String[] tokenTest = { "<PLUS,r:1>", "<MINUS,r:2>", "<TIMES,r:2>", "<DIV,r:3>",
                "<ASSIGN,r:8>", "<SEMI,r:10>", "<EOF,r:10>" };

        int i = 0;
        while (i < tokenTest.length) {
            Token token = scan.nextToken();
            assertEquals(tokenTest[i], token.toString());
            i++;
        }
    }
    
    

    @Test
    void testFLOAT() throws LexicalException {
        scan = new Scanner("test/data/testScanner/testFLOAT.txt");
        String[] tokenTest = { "<FLOAT,r:1,98.895>", "<FLOAT,r:3,98.>" };

        int i = 0;
        while (i < tokenTest.length) {
            Token token = scan.nextToken();
            assertEquals(tokenTest[i], token.toString());
            i++;
        }
        assertThrows(LexicalException.class, () -> {
            scan.nextToken();
        });
    }
    
    

    @Test
    void testScanId() throws LexicalException {
        scan = new Scanner("test/data/testScanner/testScanId.txt");
        String[] tokenTest = { "<TYINT,r:1>", "<TYFLOAT,r:2>", "<PRINT,r:3>", "<ID,r:4,nome>",
                "<ID,r:5,intnome>", "<TYINT,r:6>", "<ID,r:6,nome>", "<EOF,r:6>" };

        int i = 0;
        while (i < tokenTest.length) {
            Token token = scan.nextToken();
            assertEquals(tokenTest[i], token.toString());
            i++;
        }
    }



    @Test
    void testID() throws LexicalException {
        scan = new Scanner("test/data/testScanner/testID.txt");
        String[] tokenTest = {
                "<ID,r:1,jskjdsfhkjdshkf>",
                "<ID,r:2,printl>",
                "<ID,r:4,hhhjj>",
                "<EOF,r:5>"
        };

        int i = 0;
        while (i < tokenTest.length) {
            Token token = scan.nextToken();
            assertEquals(tokenTest[i], token.toString());
            i++;
        }
    }
    
    

    @Test
    void testEOF() throws LexicalException {
        scan = new Scanner("test/data/testScanner/testEOF.txt");
        String[] tokenTest = { "<EOF,r:4>" };

        int i = 0;
        while (i < tokenTest.length) {
            Token token = scan.nextToken();
            assertEquals(tokenTest[i], token.toString());
            i++;
        }
    }

    
    @Test
    void testErroriIdNumbers() throws LexicalException {
        scan = new Scanner("test/data/testScanner/erroriIdNumbers.txt");
        assertThrows(LexicalException.class, () -> {
            scan.nextToken();
        });
        
    }
    

    
    @Test
    void testPeekToken() throws LexicalException {
        Scanner s = new Scanner("test/data/testScanner/testGenerale.txt");
        assertEquals(s.peekToken().getType(), TokenType.TYINT);
        assertEquals(s.nextToken().getType(), TokenType.TYINT);
        assertEquals(s.peekToken().getType(), TokenType.ID);
        assertEquals(s.peekToken().getType(), TokenType.ID);
        
        Token t = s.nextToken();
        
        assertEquals(t.getType(), TokenType.ID);
        assertEquals(t.getRiga(), 1);
        assertEquals(t.getVal(), "temp");
    }
    
}
