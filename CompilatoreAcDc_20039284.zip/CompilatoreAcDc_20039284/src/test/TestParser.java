package test;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;
import scanner.Scanner;

import Parser.Parser;
import Parser.SyntacticException;
import ast.NodeProgram;
import ast.TypeDescriptor;

class TestParser {

	Parser p;
	
	NodeProgram pr;
	
	
	

	@Test
	void testEcc0() {
		p = new Parser(new Scanner("test/data/testParser/testParserEcc_0.txt"));
		assertThrows(SyntacticException.class,()->p.parse());		
	}
	@Test
	void testEcc1() {
		p = new Parser(new Scanner("test/data/testParser/testParserEcc_1.txt"));
		assertThrows(SyntacticException.class,()->p.parse());		
	}
	@Test
	void testEcc2() {
		p = new Parser(new Scanner("test/data/testParser/testParserEcc_2.txt"));
		assertThrows(SyntacticException.class,()->p.parse());		
	}
	@Test
	void testEcc3() {
		Parser p = new Parser(new Scanner("test/data/testParser/testParserEcc_3.txt"));
		assertThrows(SyntacticException.class,()->p.parse());		
	}
	@Test
	void testEcc4() {
		p = new Parser(new Scanner("test/data/testParser/testParserEcc_4.txt"));
		assertThrows(SyntacticException.class,()->p.parse());		
	}
	@Test
	void testEcc5() {
		p = new Parser(new Scanner("test/data/testParser/testParserEcc_5.txt"));
		assertThrows(SyntacticException.class,()->p.parse());		
	}
	
	@Test
	void testCorretto1() throws SyntacticException {
		Parser p = new Parser(new Scanner("test/data/testParser/testParserCorretto1.txt"));
		assertDoesNotThrow(()->p.parse());		
	}
	
	@Test
	void testCorretto2() {
		p = new Parser(new Scanner("test/data/testParser/testParserCorretto2.txt"));
		assertDoesNotThrow(()->p.parse());
	}
	
	
	@Test
	void testCorrect1() throws SyntacticException {
		Parser p = new Parser(new Scanner("test/data/testTypeCheck/2_fileCorrect.txt"));
		assertDoesNotThrow(()->pr = p.parse());
		pr.calcResType();		
		assertEquals(pr.getResType(), TypeDescriptor.OK);
		pr.calcCodice();
		assertEquals("la p P ", pr.getCodice());
		
;	}
	
	@Test
	void testCorrect2() throws SyntacticException {
		p = new Parser(new Scanner("test/data/testTypeCheck/fileCorrect2.txt"));
		assertDoesNotThrow(()->pr = p.parse());
		pr.calcResType();		
		assertEquals(pr.getResType(), TypeDescriptor.OK);
		pr.calcCodice();
		assertEquals("la 1 5 k + sa lb 1 * sb la lb 5 k - sa lb p P ", pr.getCodice());
	}
	
	
	@Test
	void testDicRipetute() throws SyntacticException {
		p = new Parser(new Scanner("test/data/testTypeCheck/1_dicRipetute.txt"));
		assertDoesNotThrow(()->pr = p.parse());
		pr.calcResType();		
		assertEquals(pr.getResType(), TypeDescriptor.ERROR);
	}
	

	@Test
	void testErrorAssignConvert() throws SyntacticException {
		p = new Parser(new Scanner("test/data/testTypeCheck/errorAssignConvert.txt"));
		assertDoesNotThrow(()->pr = p.parse());
		pr.calcResType();		
		assertEquals(pr.getResType(), TypeDescriptor.ERROR);
	}
	
	
	@Test
	void test3_IDIdNotDeclare() throws SyntacticException {
		Parser p = new Parser(new Scanner("test/data/testTypeCheck/3_IdNotDeclare.txt"));
		assertDoesNotThrow(()->pr = p.parse());
		pr.calcResType();		
		assertEquals(pr.getResType(), TypeDescriptor.ERROR);
	}
	
	
	@Test
	void testGenerale() throws SyntacticException {
		p = new Parser(new Scanner("test/data/testTypeCheck/testGenerale.txt"));
		assertDoesNotThrow(()->pr = p.parse());
		pr.calcResType();		
		assertEquals(pr.getResType(), TypeDescriptor.ERROR);
	}
	@Test
	void testGenerale2() throws SyntacticException {
		p = new Parser(new Scanner("test/data/testTypeCheck/testGenerale2.txt"));
		assertDoesNotThrow(()->pr = p.parse());
		pr.calcResType();		
		assertEquals(pr.getResType(), TypeDescriptor.OK);
		pr.calcCodice();
		assertEquals("1.0 6 5 k / sb lb p P 1 6 / sa la p P la sb ", pr.getCodice());
	}
	
	@Test
	void testErrorOp() throws SyntacticException {
		Parser p = new Parser(new Scanner("test/data/testTypeCheck/ErrorOp.txt"));
		assertDoesNotThrow(()->pr = p.parse());
		pr.calcResType();		
		assertEquals(pr.getResType(), TypeDescriptor.ERROR);
	}
	
	@Test
	void testCorretto() throws SyntacticException {
		p = new Parser(new Scanner("test/data/testGenCodice/testCorretto.txt"));
		assertDoesNotThrow(()->pr = p.parse());
		pr.calcResType();		
		assertEquals(pr.getResType(), TypeDescriptor.OK);
		pr.calcCodice();
		assertEquals("1.0 6 5 k / sb lb p P 1 6 / sa lb p P ", pr.getCodice());
	}
	
	
	

}
