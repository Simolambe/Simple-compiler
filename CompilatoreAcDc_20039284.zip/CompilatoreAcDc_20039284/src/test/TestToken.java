package test;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;

import token.Token;
import token.TokenType;

class TestToken {

    @Test
    void test() {
        
        Token token0  = new Token(TokenType.ASSIGN,1);
        
        Token token1  = new Token(TokenType.INT,1,"2");
        
        Token token2  = new Token(TokenType.EOF,3);
        
        Token token3  = new Token(TokenType.FLOAT,1,"1.0");

        Token token4  = new Token(TokenType.ID,1,"test");
        
        Token token5  = new Token(TokenType.DIV,1);
        
        Token token6  = new Token(TokenType.MINUS,1);
        
        Token token7  = new Token(TokenType.PLUS,1);
        
        Token token8  = new Token(TokenType.PRINT,1);
        
        Token token9  = new Token(TokenType.SEMI,1);
        
        Token token10 = new Token(TokenType.TIMES,1);
        
        Token token11 = new Token(TokenType.TYFLOAT,1);
        
        Token token12 = new Token(TokenType.TYINT,1);
        

        assertEquals("<ASSIGN,r:1>",token0.toString());
        
        assertEquals("<INT,r:1,2>",token1.toString());
        
        assertEquals("<EOF,r:3>",token2.toString());
        
        assertEquals("<FLOAT,r:1,1.0>",token3.toString());
        
        assertEquals("<ID,r:1,test>",token4.toString());
        
        assertEquals("<DIV,r:1>",token5.toString());
        
        assertEquals("<MINUS,r:1>",token6.toString());
        
        assertEquals("<PLUS,r:1>",token7.toString());
        
        assertEquals("<PRINT,r:1>",token8.toString());
        
        assertEquals("<SEMI,r:1>",token9.toString());
        
        assertEquals("<TIMES,r:1>",token10.toString());
        
        assertEquals("<TYFLOAT,r:1>",token11.toString());
        
        assertEquals("<TYINT,r:1>",token12.toString());
        
    }

}
