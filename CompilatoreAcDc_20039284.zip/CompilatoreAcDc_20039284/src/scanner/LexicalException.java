package scanner;

public class LexicalException extends Exception {
	public LexicalException(String message, Throwable cause) {
		super(message, cause);
	}
}
