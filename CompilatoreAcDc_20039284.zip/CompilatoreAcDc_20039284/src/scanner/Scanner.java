package scanner;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.io.PushbackReader;
import token.*;



public class Scanner {
	final char EOF = (char) -1;
	private int riga;
	private PushbackReader buffer;  // Buffer per leggere i caratteri dal file con supporto per
	private String log;  //Usato per accumulare i caratteri letti durante la scansione di numeri e identificatori.
	private Token token;

	// skipChars: insieme caratteri di skip (include EOF) e inizializzazione
	List<Character> skipChars = new ArrayList<Character>();
  
	// lettere: insieme lettere e inizializzazione
	List<Character> lettere = new ArrayList<Character>();
	
	// digits: cifre e inizializzazione
	List<Character> digits = new ArrayList<Character>();

	
	// char_type_Map: mapping fra caratteri '+', '-', '*', '/', '=', ';' e il
		// TokenType corrispondente
		Map<Character,TokenType> operatrMap = new HashMap<Character,TokenType>();
		
		// keyWordsMap: mapping fra le stringhe "print", "float", "int" e il TokenType  corrispondente
		public Map<String, TokenType> keyWordsMap = new HashMap<String,TokenType>();

	public Scanner(String fileName) {
		//legge il nome del file, se non lo trova termina 
		try {
			this.buffer = new PushbackReader(new FileReader(fileName));
		}
		catch (FileNotFoundException e) {
			System.out.println("Non � stato trovato alcun file: " + e.getMessage());
			System.exit(0);
		}
		
		riga = 1;
		token = null;
		
		//Caratteri da skippare
		Character[] skip = {' ','\n','\t','\r', EOF};
		this.skipChars.addAll(Arrays.asList(skip));
		
		//Lettere riconoscibili
		String lettera = "abcdefghikjlmnopqrstuwxyvz";
		for(char l : lettera.toCharArray()) 
		    this.lettere.add(l);
		
		//Numeri riconoscibili
		String numeri = "0123456789";
		for(char n : numeri.toCharArray()) 
		    this.digits.add(n);
		
		this.operatrMap = Map.of('+',TokenType.PLUS,
								 '-',TokenType.MINUS,
								 '*',TokenType.TIMES,
								 '/',TokenType.DIV,
								 '=',TokenType.ASSIGN,
								 ';',TokenType.SEMI
								 );
		this.keyWordsMap = Map.of("print",TokenType.PRINT,
								  "float",TokenType.TYFLOAT,
								  "int",TokenType.TYINT
								  );
		
	}
	

	public Token nextToken() throws LexicalException {
		char nextChar = ' ';
		try {
			// nextChar contiene il prossimo carattere dell'input (non consumato).
			nextChar = this.peekChar();
			
			//se token non � nullo vuol dire che � gi� stato generato con la peekToken(), dunque lo ritorno e lo annullo per lo scanToken() successivo
			
			if(this.token != null) {
				Token tmpTok = this.token;
				this.token = null;
				return tmpTok;
			}
			
			// Avanza nel buffer leggendo i caratteri skippabili
			while (this.skipChars.contains(nextChar)) {
				nextChar = this.readChar();
				// incrementa la riga se leggi il carattere '\n'.
				if (nextChar == '\n') this.riga++;
				// Se raggiungi la fine del file ritorna il Token EOF
				if (nextChar == EOF) return new Token(TokenType.EOF,this.riga); 
				nextChar = this.peekChar();
			}
			
			
			// Se nextChar e' in numeri
			// return scanNumber()
			// che legge sia un intero che un float e ritorna il Token INUM o FNUM
			// i caratteri che leggete devono essere accumulati in una stringa
			// che verra' assegnata al campo valore del Token
			if (this.digits.contains(nextChar)) 
				return this.scanNumber();
	
			// Se nextChar e' in lettere
			// return scanId()
			// che legge tutte le lettere minuscole e ritorna un Token ID o
			// il Token associato Parola Chiave (per generare i Token per le
			// parole chiave usate l'HaskMap di corrispondenza
			if (this.lettere.contains(nextChar)) 
				return this.scanId();
	
			// Se nextChar e' in operators
			// ritorna il Token associato con l'operatore o il delimitatore
			if (this.operatrMap.containsKey(nextChar)) {
				this.readChar();
				return new Token(this.operatrMap.get(nextChar),this.riga);
			}
	
			// Altrimenti il carattere NON E' UN CARATTERE LEGALE
			throw new IOException("Errore: Carattere "+nextChar+" non riconosciuto");
		}
		catch (IOException e) {
			throw new LexicalException("Errore: Carattere "+nextChar+" non riconosciuto alla riga: "+this.riga, e);
		}
	}
	
	public Token peekToken() throws LexicalException{ 
		if(this.token == null)
			token = this.nextToken();
		return token;
	}

	 private Token scanNumber() throws IOException {	
		 
		 int flag = 0; //la flag verr� impostata a 0 se il numero � tipo int, 1 se il numero � tipo float
		 this.log = "";
		 
		//leggi il numero
		 char nextChar = this.peekChar();
		 
		//se il numero � 0
		if(nextChar == '0') {
			this.log += this.readChar();
			nextChar = this.peekChar();
			if(this.lettere.contains(nextChar) || this.digits.contains(nextChar))
				throw new IOException("carattere non valido: "+" "+this.peekChar()+" - log: "+this.log);
		}
		
		//se il numero non inizia con 0 
		else
			while(this.digits.contains(nextChar)){
				this.log += this.readChar();	
				nextChar = this.peekChar();		
			}
		
		//se il numero � un float
		if(nextChar == '.') {
			flag = 1; 
			this.log += this.readChar();
			for(int i=0;i<5;i++) {
				if(this.digits.contains(nextChar))
					this.log += this.readChar();
				nextChar = this.peekChar();	
			}
		}
		//quando incontro un carattere di spaziatura genero il token e chiudo il metodo
		if(this.skipChars.contains(this.peekChar()) || this.operatrMap.containsKey(this.peekChar()))
			if(flag == 0)
				return new Token(TokenType.INT,this.riga,this.log);
			else
				return new Token(TokenType.FLOAT,this.riga,this.log);
		
		//quando incontro un carattere diverso lancio un'eccezione
		throw new IOException("carattere non valido: "+" "+this.peekChar()+" - log: "+this.log);
	 }

	private Token scanId() throws IOException {
		this.log = "";
		char nextChar = this.peekChar();
		
		
		while(this.lettere.contains(nextChar)) {
			this.log += this.readChar();
			nextChar = this.peekChar();			
		}
		if(this.skipChars.contains(nextChar) || this.operatrMap.containsKey(nextChar)) {
			if(this.keyWordsMap.containsKey(log))
				//la parola � una parola chiave
				return new Token(this.keyWordsMap.get(log),this.riga);
			else
				//la parola � un ID
				return new Token(TokenType.ID,this.riga,this.log);
		}
		
		throw new IOException("parola non valida: "+this.readChar()+" riga:"+this.riga+ " log:"+this.log);	
	}

	private char readChar() throws IOException {
		return ((char) this.buffer.read());
	}

	private char peekChar() throws IOException {
		char c = (char) buffer.read();
		buffer.unread(c);
		return c;
	}
}
