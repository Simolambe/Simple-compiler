package Parser;

public class SyntacticException extends Exception {
    private static final long serialVersionUID = 1L;  

    public SyntacticException(String message, Throwable cause) {
        super(message, cause);
    }

    public SyntacticException(String message, int line) {
        super("Errore alla linea " + line + ": " + message);
    }
}
