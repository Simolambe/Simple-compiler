package Parser;

import java.util.ArrayList;

import ast.*;

import scanner.LexicalException;
import scanner.Scanner;
import symbolTable.Registers;
import symbolTable.SymbolTable;
import symbolTable.Attributes;
import token.Token;
import token.TokenType;

public class Parser {
	
	Scanner scanner;
	
	public Parser(Scanner scanner) {
		super();
		this.scanner = scanner;
		SymbolTable.init();
		Registers.init();
	}
	
	
	public NodeProgram parse() throws SyntacticException {
		return this.parsePrg();
	}
	
	//consuma il token successivo e ritorna errore se non � dello stesso tipo atteso
		public Token match(TokenType type) throws SyntacticException  {
			Token tok = new Token();
			try{
				tok = this.scanner.peekToken();
				if(type.equals(tok.getType()))
					return this.scanner.nextToken();
				else 
					throw new SyntacticException("token "+tok.getType()+" diverso dal token "+type+" atteso", tok.getRiga());
			}catch (LexicalException e){
				//input non valido
				throw new SyntacticException("Errore nell'input: "+e.getCause(), tok.getRiga());
			}		
	}
	
	
	private NodeProgram parsePrg() throws SyntacticException {
		Token tok = new Token();
		try{
			tok = this.scanner.peekToken();
		}catch(LexicalException e) {
			throw new SyntacticException("Lexical Exception: ",e);
		}
		switch(tok.getType()) {
			//Prg -> DSs $
			case TYFLOAT, TYINT, ID, PRINT, EOF:
				NodeProgram prog = new NodeProgram(this.parseDSs());
				this.match(TokenType.EOF);
				return prog;
			default:
				throw new SyntacticException("Il token che � stato letto: "+tok.getType()+" non risulta essere quello atteso", tok.getRiga());
		}
	}

	private ArrayList<NodeDecSt> parseDSs() throws SyntacticException {
		Token tok;
		ArrayList<NodeDecSt> decs;
		try{
			tok = this.scanner.peekToken();
		}
		catch(LexicalException e) {
			throw new SyntacticException("Lexical Exception: ",e);
		}
		switch(tok.getType()) {
			//DSs -> Dcl DSs
			case TYFLOAT, TYINT:
				NodeDecl decl = this.parseDcl();
				decs = this.parseDSs();
				decs.add(0, decl);
				return decs;
			//DSs -> Stm DSs
			case ID, PRINT:
				NodeStm stm = this.parseStm();
				decs = this.parseDSs();
				decs.add(0, stm);
				return decs;
			//DSs -> epsilon
			case EOF:
				return new ArrayList<NodeDecSt>();
		default:
			throw new SyntacticException("Il token che � stato letto: "+tok.getType()+" non risulta essere quello atteso", tok.getRiga());
		}
	}
	
	private NodeDecl parseDcl() throws SyntacticException {
		Token tok = new Token();
		try{
			tok = this.scanner.peekToken();
		}
		catch(LexicalException e) {
			throw new SyntacticException("Lexical Exception: ",e);
		}
		LangType ty;
		Token tokId;
		NodeExpr init;
		switch(tok.getType()) {
			//Dcl -> Ty id DclP
			case TYFLOAT, TYINT:
				ty = this.parseTy();
				tokId = this.match(TokenType.ID);
				init = this.parseDclP();
				//se è già presente variable con lo stesso nome nella symbol table
				//imposto il resType del NodeId a ERROR
				if(SymbolTable.lookup(tokId.getVal()) != null) {
					NodeId id = new NodeId(tokId.getVal());
					id.setResType(TypeDescriptor.ERROR);
					return new NodeDecl(id,ty,init);
				}
				SymbolTable.enter(tokId.getVal(), new Attributes(ty,Registers.newRegister()));
				return new NodeDecl(new NodeId(tokId.getVal()), ty, init);
				 
		default:
			throw new SyntacticException("Il token che � stato letto: "+tok.getType()+" non risulta essere quello atteso", tok.getRiga());
		}
	}
	
	
	private LangType parseTy() throws SyntacticException {
		Token tok = new Token();
		try{
			tok = this.scanner.peekToken();
		}
		catch(LexicalException e) {
			throw new SyntacticException("Lexical Exception: ",e);
		}
		switch(tok.getType()) {
			//Ty -> float
			case TYFLOAT:
				this.match(TokenType.TYFLOAT);
				return LangType.FLOAT;
			//Ty -> int
			case TYINT:
				this.match(TokenType.TYINT);
				return LangType.INT;
		default:
			throw new SyntacticException("Il token che � stato letto: "+tok.getType()+" non risulta essere quello atteso", tok.getRiga()) ;
		}
	}
	
	
	private NodeExpr parseDclP() throws SyntacticException {
		Token tok = new Token();
		try{
			tok = this.scanner.peekToken();
		}
		catch(LexicalException e) {
			throw new SyntacticException("Lexical Exception: ",e);
		}
		NodeExpr expr;
		switch(tok.getType()) {
			//DclP -> ;
			case SEMI:
				this.match(TokenType.SEMI);
				return null;
			//DclP -> = Exp;
			case ASSIGN:
				this.match(TokenType.ASSIGN);
				expr = this.parseExp();
				this.match(TokenType.SEMI);
				return expr;
		default:
			throw new SyntacticException("Il token che � stato letto: "+tok.getType()+" non risulta essere quello atteso", tok.getRiga());
		}
	}


	private NodeStm parseStm() throws SyntacticException {
		Token tok = new Token();
		try{
			tok = this.scanner.peekToken();
		}
		catch(LexicalException e) {
			throw new SyntacticException("Lexical Exception: ",e);
		}
		Token tokId;
		NodeExpr expr;
		switch(tok.getType()) {
			//Stm -> id = Exp;
			case ID:
				tokId = this.match(TokenType.ID);
				this.match(TokenType.ASSIGN);
				expr = this.parseExp();
				this.match(TokenType.SEMI);
				return new NodeAssign(new NodeId(tokId.getVal()),expr);
			//Stm ->  print id;
			case PRINT:
				this.match(TokenType.PRINT);
				tokId = this.match(TokenType.ID);
				this.match(TokenType.SEMI);
				return new NodePrint(new NodeId(tokId.getVal()));
		default:
			throw new SyntacticException("Il token che � stato letto: "+tok.getType()+" non risulta essere quello atteso", tok.getRiga());
		}
	}






	private NodeExpr parseExp() throws SyntacticException {
		Token tok = new Token();
		try{
			tok = this.scanner.peekToken();
		}
		catch(LexicalException e) {
			throw new SyntacticException("Lexical Exception: ",e);
		}
		NodeExpr left;
		NodeExpr expr;
		switch(tok.getType()) {
			//Exp -> Tr ExpP
			case INT,FLOAT,ID:
				left = this.parseTr();
				expr = this.parseExpP(left);
				return expr;
		default:
			throw new SyntacticException("Il token che � stato letto: "+tok.getType()+" non risulta essere quello atteso", tok.getRiga()) ;
		}
	}
	
	private NodeExpr parseExpP(NodeExpr left) throws SyntacticException {
		Token tok = new Token();
		try{
			tok = this.scanner.peekToken();
		}
		catch(LexicalException e) {
			throw new SyntacticException("Lexical Exception: ",e);
		}
		LangOper op;
		NodeExpr tr;
		NodeExpr expr;
		switch(tok.getType()) {
			//ExpP -> + Tr ExpP
			case PLUS:
				this.match(TokenType.PLUS);
				op = LangOper.PLUS;
				tr = this.parseTr();
				
				left.calcResType();
				tr.calcResType();
				if(left.getResType() == TypeDescriptor.FLOAT 
						&& tr.getResType() == TypeDescriptor.INT)
					expr = this.parseExpP(new NodeBinOp(op,left,new NodeConvert(tr)));
				else
					expr = this.parseExpP(new NodeBinOp(op,left,tr));
				return expr;
			//ExpP -> - Tr ExpP
			case MINUS:
				this.match(TokenType.MINUS);
				op = LangOper.MINUS;
				tr = this.parseTr();
				
				left.calcResType();
				tr.calcResType();
				if(left.getResType() == TypeDescriptor.FLOAT 
						&& tr.getResType() == TypeDescriptor.INT)
					expr = this.parseExpP(new NodeBinOp(op,left,new NodeConvert(tr)));
				else
					expr = this.parseExpP(new NodeBinOp(op,left,tr));
				return expr;
			//ExpP -> epsilon
			case SEMI:
				return left;
				
		default:
			throw new SyntacticException("Il token che � stato letto: "+tok.getType()+" non risulta essere quello atteso", tok.getRiga()) ;
		}
	}
	
	private NodeExpr parseTr() throws SyntacticException {
		Token tok = new Token();
		try{
			tok = this.scanner.peekToken();
		}catch(LexicalException e) {

			throw new SyntacticException("Lexical Exception: ",e);
		}
		NodeExpr left;
		NodeExpr expr;
		switch(tok.getType()) {
			//Tr -> Val TrP
			case INT, FLOAT, ID:
				left = this.parseVal();
				expr = this.parseTrP(left);
				return expr;
		default:
			throw new SyntacticException("Il token che � stato letto: "+tok.getType()+" non risulta essere quello atteso", tok.getRiga()) ;
		}
	}
	
	private NodeExpr parseTrP(NodeExpr left) throws SyntacticException {
		Token tok = new Token();
		try{
			tok = this.scanner.peekToken();
		}catch(LexicalException e) {
			throw new SyntacticException("Lexical Exception: ",e);
		}
		LangOper op;
		NodeExpr val;
		NodeExpr expr;
		switch(tok.getType()) {
			//TrP -> * Val TrP
			case TIMES:
				this.match(TokenType.TIMES);
				op = LangOper.TIMES;
				val = this.parseVal();
				
				left.calcResType();
				val.calcResType();
				if(left.getResType() == TypeDescriptor.FLOAT 
						&& val.getResType() == TypeDescriptor.INT)
					expr = this.parseTrP(new NodeBinOp(op,left,new NodeConvert(val)));
				else
					expr = this.parseTrP(new NodeBinOp(op,left,val));
				return expr;
			//TrP -> / Val TrP
			case DIV:
				this.match(TokenType.DIV);
				op = LangOper.DIV;
				val = this.parseVal();
				
				left.calcResType();
				val.calcResType();
				if(left.getResType() == TypeDescriptor.FLOAT 
						&& val.getResType() == TypeDescriptor.INT)
					expr = this.parseTrP(new NodeBinOp(op,left,new NodeConvert(val)));
				else
					expr = this.parseTrP(new NodeBinOp(op,left,val));
				return expr;
			//TrP -> epsilon
			case PLUS,MINUS,SEMI:
				return left;
		default:
			throw new SyntacticException("Il token che � stato letto: "+tok.getType()+" non risulta essere quello atteso", tok.getRiga()) ;
		}
	}
	
	private NodeExpr parseVal() throws SyntacticException {
		Token tok = new Token();
		try{
			tok = this.scanner.peekToken();
		}catch(LexicalException e) {
			throw new SyntacticException("Lexical Exception: ",e);
		}
		Token tokVal;
		LangType type;
		switch(tok.getType()) {
			//Val -> intVal
			case INT:
				tokVal = this.match(TokenType.INT);
				type = LangType.INT;
				return new NodeCost(tokVal.getVal(),type);
			//Val -> FloatVal
			case FLOAT:
				tokVal = this.match(TokenType.FLOAT);
				type = LangType.FLOAT;
				return new NodeCost(tokVal.getVal(),type);
			//Val -> id
			case ID:
				tokVal = this.match(TokenType.ID);
				return new NodeDeref(new NodeId(tokVal.getVal()));
		default:
			throw new SyntacticException("Il token che � stato letto: "+tok.getType()+" non risulta essere quello atteso", tok.getRiga()) ;
		}
	}

}
