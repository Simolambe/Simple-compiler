package symbolTable;

import java.util.ArrayList;

public class Registers {
	
	private static ArrayList<Character> register; 
	
	
	public static void init() {
		register = new ArrayList<>();
		String lettera = "abcdefghikjlmnopqrstuvwxyz";
		for(char c : lettera.toCharArray()) 
		    register.add(c);
	}
	
	
	public static char newRegister() {
		return register.remove(0);
	}
}
