package symbolTable;

import ast.LangType;

public class Attributes {
	LangType type;
	char register;

	public Attributes(LangType type,char register) {
		this.type = type;
		this.register = register;
	}
	
	public LangType getType() {
		return type;
	}

	public void setType(LangType type) {
		this.type = type;
	}

	public char getRegister() {
		return register;
	}

	public void setRegister(char register) {
		this.register = register;
	}
	
	
}
