package symbolTable;

import java.util.HashMap;

public class SymbolTable {
	private static HashMap<String, Attributes> table;

	public static void init() {
		table = new HashMap<>();;
	}
	
	public static boolean enter(String id, Attributes attributes) {
		if (table.get(id) != null) return false;		
		
		table.put(id, attributes);
		return true;
	}
	public static Attributes lookup(String id) {
		return table.get(id);
	}
	
	public static boolean contains(String id) {
		return table.containsKey(id);
	}
	
	public static int size() {
		return table.size();
	}
	
	public static String printSymbol() {
		return table.toString();
	}
}
