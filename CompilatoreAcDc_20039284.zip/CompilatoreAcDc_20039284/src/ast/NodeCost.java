package ast;

public class NodeCost extends NodeExpr{
	private String value;
	private LangType type;
	
	public NodeCost(String value, LangType type) {
		super();
		this.value = value;
		this.type = type;
		this.resType = null;
	}
	public String getValue() {
	
		return value;
	}
	
	public LangType getType() {
	
		return type;
	}
	
	@Override
	public String toString() {
		return "\n\t\tNodeCost [" + (value != null ? "value=" + value + ", " : "") + (type != null ? "type=" + type : "")
				+ "]";
	}
	@Override
	public void calcResType() {
		if(type == LangType.INT)
			resType = TypeDescriptor.INT;
		
		if(type == LangType.FLOAT)
			resType = TypeDescriptor.FLOAT;		
	}
	@Override
	public void calcCodice() {
		codice = value+" ";
		
	}
	
}
