package ast;

public class NodeConvert extends NodeExpr{
	private NodeExpr expr;
	
	
	public NodeConvert(NodeExpr expr) {
		super();
		this.expr = expr;
	}
	
	public NodeExpr getExpr() {
		return expr;
	}

	@Override
	public String toString() {
		return "NodeConvert [" + (expr != null ? "expr=" + expr : "") + "]";
	}

	@Override
	public void calcResType() {
		this.expr.calcResType();
		resType = this.expr.getResType();		
	}

	
	@Override
	public void calcCodice() {
		expr.calcCodice();
		codice = expr.getCodice()+"5 k ";		
	}
	
}
