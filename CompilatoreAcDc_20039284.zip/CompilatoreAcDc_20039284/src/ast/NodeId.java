package ast;

import symbolTable.Attributes;
import symbolTable.SymbolTable;

public class NodeId extends NodeAST {
	
	private String name;
	private Attributes definition;

	public NodeId(String name) {
		super();
		this.name = name;
		this.resType = null;
		this.definition = SymbolTable.lookup(name);
	}

	public String getName() {
		return name;
	}
	
	public void setResType(TypeDescriptor type) {
		resType = type;
	}
	

	public Attributes getDefinition() {
		return definition;
	}

	@Override
	public String toString() {
		return "NodeID [" + (name != null ? "name=" + name+"" : "") + "]";
	}

	@Override
	public void calcResType() {
		if(resType != null)
			return;
		Attributes def = this.definition;
		
		
		if (def == null)
			resType = TypeDescriptor.ERROR;
		
		else if (def.getType() == LangType.INT) {
			resType = TypeDescriptor.INT;
			this.definition = def;
		}			
		else if (def.getType() == LangType.FLOAT) {
			resType = TypeDescriptor.FLOAT;
			this.definition = def;
		}			
		else
			resType = TypeDescriptor.ERROR;
	}

	@Override
	public void calcCodice() {
		codice = ""+this.definition.getRegister()+" ";		
	}

}
