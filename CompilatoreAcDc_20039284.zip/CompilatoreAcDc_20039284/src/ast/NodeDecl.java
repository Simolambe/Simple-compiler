package ast;

public class NodeDecl extends NodeDecSt{
	private NodeId id;
	private LangType type;
	private NodeExpr init;
	
	public NodeDecl(NodeId id, LangType type, NodeExpr init) {
		super();
		this.id = id;
		this.type = type;
		this.init = init;
	}

	public NodeId getId() {
		
		return id;
	}

	public LangType getType() {
		
		return type;
	}

	public NodeExpr getInit() {
		
		return init;
	}

	@Override
	public String toString() {
		return "\n\tNodeDecCl [" + (id != null ? "id=" + id + ", " : "") + (type != null ? "type=" + type + ", " : "")
				+ (init != null ? "init=" + init : "") + "]";
	}

	@Override
	public void calcResType() {
		id.calcResType();
		if(init == null) {
			if(id.getResType() == TypeDescriptor.FLOAT || id.getResType() == TypeDescriptor.INT )
				resType = TypeDescriptor.OK;
			else
				resType = TypeDescriptor.ERROR;
		}
		else {
			init.calcResType();
			if(id.getResType() == init.getResType())
				resType = TypeDescriptor.OK;	
			else if(id.getResType() == TypeDescriptor.FLOAT && init.getResType() == TypeDescriptor.INT)
				resType = id.getResType();
			else
				resType = TypeDescriptor.ERROR;
		}
	}
	

	@Override
	public void calcCodice() {
		codice="";
		if(init != null) {
			id.calcCodice();
			codice=init.getCodice()+"s"+id.getCodice();
		}
	}
	

}
