package ast;

public enum TypeDescriptor {
	INT,
	FLOAT,
	OK,
	ERROR
}
