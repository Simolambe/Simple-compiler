package ast;

public abstract class NodeDecSt extends NodeAST{
	
}
