package ast;

public class NodeBinOp extends NodeExpr{
	private LangOper op;
	private NodeExpr left;
	private NodeExpr right;
	
	public NodeBinOp(LangOper op, NodeExpr left, NodeExpr right) {
		super();
		this.op = op;
		this.left = left;
		this.right = right;
	}
	public LangOper getOp() {
		
		return op;
	}
	public NodeExpr getLeft() {
		
		return left;
	}
	public NodeExpr getRight() {
		
		return right;
	}
	@Override
	public String toString() {
		return "\n\t\tNodeBinOp [" + (op != null ? "op=" + op + ", " : "") + (left != null ? "left=" + left + ", " : "")
				+ (right != null ? "right=" + right : "") + "]";
	}
	@Override
	public void calcResType() {
		left.calcResType();
		right.calcResType();
		
		if(left.getResType() == right.getResType())
			resType = left.getResType();
		else if(left.getResType() == TypeDescriptor.FLOAT && right.getResType() == TypeDescriptor.INT)
			resType = left.getResType();
		else
			resType = TypeDescriptor.ERROR;
	}
	@Override
	public void calcCodice() {
		left.calcCodice();
		right.calcCodice();
		char op = ' ';
		
		if(this.op == LangOper.PLUS)
			op = '+';
		else if(this.op == LangOper.MINUS)
			op = '-';
		else if(this.op == LangOper.TIMES)
			op = '*';
		else if(this.op == LangOper.DIV)
			op = '/';
		
		codice = left.getCodice()+right.getCodice()+op+" ";
	
	}	
	
	

}
