package ast;

public class NodeAssign extends NodeStm{
	private NodeId id;
	private NodeExpr expr;
	
	public NodeAssign(NodeId id, NodeExpr expr) {
		super();
		this.id = id;
		this.expr = expr;
		this.resType = null;
	}
	
	public NodeId getId() {
	
		return id;
	}
	public NodeExpr getExpr() {
		
		return expr;
	}
	
	@Override
	public String toString() {
		return "\n\tNodeAssign [" + (id != null ? "id=" + id + ", " : "") + (expr != null ? "expr=" + expr : "") + "]";
	}
	
	@Override
	public void calcResType() {
		id.calcResType();
		expr.calcResType();
		if(id.getResType() == expr.getResType())
			resType = TypeDescriptor.OK;
		else if(id.getResType() == TypeDescriptor.FLOAT && expr.getResType() == TypeDescriptor.INT)
			resType = TypeDescriptor.OK;
		else
			resType = TypeDescriptor.ERROR;
		
	}
	@Override
	public void calcCodice() {
		id.calcCodice();
		expr.calcCodice();
		codice = expr.getCodice()+"s"+id.getCodice();
		
	}
	
	
}
