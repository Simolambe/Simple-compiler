package ast;

public class NodePrint extends NodeStm{
	private NodeId id;

	public NodePrint(NodeId id) {
		super();
		this.id = id;
		this.resType = null;
	}
	
	public NodeId getId() {
		return id;
	}

	@Override
	public String toString() {
		return "\n\tNodePrint [" + (id != null ? "id=" + id+"" : "") + "]";
	}

	@Override
	public void calcResType() {
		id.calcResType();
		if(id.getResType() == TypeDescriptor.ERROR) 
			resType = TypeDescriptor.ERROR;
		else
			resType = TypeDescriptor.OK;
	}

	@Override
	public void calcCodice() {
		id.calcCodice();
		codice="l"+id.getCodice()+"p P ";
		
	}
	
}
