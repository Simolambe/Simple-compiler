package ast;

public abstract class NodeAST {
	protected TypeDescriptor resType;
	protected String codice;
	
	public abstract void calcResType();
	
	public TypeDescriptor getResType() {
		return this.resType;
	}
	
	public abstract void calcCodice();
	
	
	public String getCodice() {
		return this.codice;
	}
	
}
