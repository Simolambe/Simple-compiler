package ast;

import java.util.ArrayList;

public class NodeProgram extends NodeAST{

	private ArrayList<NodeDecSt> decSts = new ArrayList<>();

	public NodeProgram(ArrayList<NodeDecSt> decSts) {
		super();
		this.decSts = decSts;
		this.resType = null;
	}
	
	public NodeDecSt get(int index) {
		return this.decSts.get(index);
	}
	
	public void add(NodeDecSt node) {
		this.decSts.add(node);
	}

	@Override
	public String toString() {
		 return "NodeProgram [" + (decSts != null ? "decSts=" + decSts+"" : "") + "]\n\n";
	}

	@Override
	public void calcResType() {
		for(NodeAST node: this.decSts) {
			node.calcResType();
			//System.out.println(node.toString());
			if(node.getResType() != TypeDescriptor.OK) {
				resType = TypeDescriptor.ERROR;
				return;
			}
		}	
		resType = TypeDescriptor.OK;
	}

	@Override
	public void calcCodice() {
		codice = "";
		for(NodeAST node : this.decSts) {
			node.calcCodice();
			codice+=node.getCodice();
		}
	}
}
