package ast;

public class NodeDeref extends NodeExpr{
	private NodeId id;

	public NodeDeref(NodeId id) {
		super();
		this.id = id;
		this.resType = null;
	}

	public NodeId getId() {
		return id;
	}

	@Override
	public String toString() {
		return "\n\t\tNodeDeref [" + (id != null ? "id=" + id : "") + "]";
	}

	@Override
	public void calcResType() {
		id.calcResType();	
		if(id.getResType() == TypeDescriptor.INT)
			resType = TypeDescriptor.INT;
		
		if(id.getResType() == TypeDescriptor.FLOAT)
			resType = TypeDescriptor.FLOAT;
	}
	

	@Override
	public void calcCodice() {
		id.calcCodice();
		codice="l"+id.getCodice();
		
	}

}
