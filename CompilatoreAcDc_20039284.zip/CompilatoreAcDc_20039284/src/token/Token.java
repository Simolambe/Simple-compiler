package token;

public class Token {
	
	private int riga; 
	private TokenType tipo; 
	private String val; 
							
	public Token(TokenType tipo, int riga, String val) {
		super();
		this.riga = riga;
		this.tipo = tipo;
		this.val = val;
	}	

	public Token(TokenType tipo, int riga) {
		super();
		this.riga = riga;
		this.tipo = tipo;
	}
	
	// Per il Token end Of File
	public Token() {
		this.riga = -1;
		this.tipo = TokenType.EOF;
		this.val = "";
	}

	
    // Getters per i campi

	public TokenType getType() {
		return tipo;
	}
	
	public int getRiga() {
		return riga;
	}

	public String getVal() {
		return val;
	}

	@Override
	public String toString() {
		return "<"+tipo+",r:"+riga+(val != null ? ","+val : "")+">";
	}
	
}
