package token;

public enum TokenType {
	INT,
	FLOAT,
	ID,
	TYINT,
	TYFLOAT,
	PRINT,
	ASSIGN,
	PLUS,
	MINUS,
	TIMES,
	DIV,
	SEMI,
	EOF;
}
